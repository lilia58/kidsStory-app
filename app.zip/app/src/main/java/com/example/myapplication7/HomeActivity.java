package com.example.myapplication7;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Afficher un message de bienvenue
        TextView welcomeText = findViewById(R.id.welcomeText);
        welcomeText.setText("Bienvenue sur MonPanier !");
    }
}
